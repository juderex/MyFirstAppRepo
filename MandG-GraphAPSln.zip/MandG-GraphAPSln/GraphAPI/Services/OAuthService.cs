﻿using GraphAPI.Clients;
using GraphAPI.Models.OAuth;
using System.Threading.Tasks;

namespace GraphAPI.Services
{
    #region IOAuthService
    public interface IOAuthService
    {
        Task<OAuthToken> GetToken();
    }
    #endregion

    #region OAuthService
    public class OAuthService : IOAuthService
    {
        private readonly IOAuthClient _oAuthClient;

        #region Constructor-OAuthService
        public OAuthService(IOAuthClient oAuthClient)
        {
            _oAuthClient = oAuthClient;
        }
        #endregion

        #region GetToken
        public async Task<OAuthToken> GetToken()
        {
            var oauthToken = await _oAuthClient.GetToken();
            return oauthToken;
        }
        #endregion
    }
    #endregion
}
