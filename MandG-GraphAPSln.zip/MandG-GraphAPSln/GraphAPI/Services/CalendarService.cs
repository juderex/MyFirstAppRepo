﻿using GraphAPI.Clients;
using GraphAPI.Models.Calendar;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace GraphAPI.Services
{
    #region IOAuthService
    public interface ICalendarService
    {
        Task<CalendarResponse> GetCalendarsList();
        Task<CalendarResponse> CreateEvent(CreateEventRequestModel eventParams);
        Task<CalendarResponse> CreateEventMultiLocations(CreateEventMultiLocRequestModel eventMultiLocParams);
        Task<CalendarResponse> CreateEventRecurrent(CreateEventRecurrentRequestModel eventRecurrentParams);
    }
    #endregion
    public class CalendarService : ICalendarService
    {
        private readonly ICalendarClient _calendarClient;
        private readonly ILogger<CalendarService> _logger;

        #region Constructor-CalendarService
        public CalendarService(ICalendarClient calendarClient, ILogger<CalendarService> logger)
        {
            _calendarClient = calendarClient;
            _logger = logger;
        }
        #endregion
        public async Task<CalendarResponse> GetCalendarsList()
        {
            var calendarList = await _calendarClient.GetCalendarAllLists();
            return calendarList;
        }

        #region CreateEvent
        public async Task<CalendarResponse> CreateEvent(CreateEventRequestModel eventParams)
        {
            var calendarList = await _calendarClient.CreateEvent(eventParams);
            return calendarList;
        }
        #endregion

        #region CreateEventMultiLocations
        public async Task<CalendarResponse> CreateEventMultiLocations(CreateEventMultiLocRequestModel eventMultiLocParams)
        {
            var calendarList = await _calendarClient.CreateEventMultiLocations(eventMultiLocParams);
            return calendarList;
        }
        #endregion

        #region CreateEventRecurrent
        public async Task<CalendarResponse> CreateEventRecurrent(CreateEventRecurrentRequestModel eventRecurrentParams)
        {
            var calendarList = await _calendarClient.CreateEventRecurrent(eventRecurrentParams);
            return calendarList;
        }
        #endregion
    }
}
