﻿namespace GraphAPI.Configuration
{
    public class AppSettings
    {
        public OAuthTokenSettings OAuthToken { get; set; }
        public GraphAPISettings GraphAPI { get; set; }
        public AuthenticationSettings BasicAuth { get; set; }
    }
    public class OAuthTokenSettings
    {
        public const string Position = "OAuthToken";
        public string BaseUrl { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string Scope { get; set; }
        public string TenantId { get; set; }
    }

    public class GraphAPISettings
    {
        public const string Position = "GraphAPI";
        public string BaseUrl { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string Scope { get; set; }
    }

    public class AuthenticationSettings
    {
        public const string Position = "BasicAuth";
        public string BasicAuthentication { get; set; }
        public string TokenName { get; set; }
    }
}
