﻿using GraphAPI.Configuration;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Threading.Tasks;

namespace GraphAPI.Handler
{
    public class BasicAuthenticationOptions : AuthenticationSchemeOptions
    {
    }
    public class MandGAuthenticationHandler : AuthenticationHandler<BasicAuthenticationOptions>
    {
        private readonly IDictionary<string, string> tokens = new Dictionary<string, string>();
        private AuthenticationSettings _authSettings;
        private readonly ILogger<MandGAuthenticationHandler> _logger; // Adding the ILogger service  
        private static string _logPrefix = "MandG Graph API - ";
        public IDictionary<string, string> Tokens => tokens;
        public MandGAuthenticationHandler(
           IOptionsMonitor<BasicAuthenticationOptions> options,
           IOptions<AuthenticationSettings> authSettings,
           ILoggerFactory logger,
           ILogger<MandGAuthenticationHandler> loggerHandler,
           UrlEncoder encoder,
           ISystemClock clock)
           : base(options, logger, encoder, clock)
        {
            _authSettings = authSettings.Value;
            _logger = loggerHandler;
        }

        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            _logger.LogInformation($"{ _logPrefix }, calling handle authenticate async method...");

            if (!Request.Headers.ContainsKey("Authorization"))
                return AuthenticateResult.Fail("Unauthorized");

            string authorizationHeader = Request.Headers["Authorization"];

            if (string.IsNullOrEmpty(authorizationHeader))
            {
                return AuthenticateResult.NoResult();
            }

            if (!authorizationHeader.StartsWith("basic", StringComparison.OrdinalIgnoreCase))
            {
                return AuthenticateResult.Fail("Unauthorized");
            }

            string token = authorizationHeader.Substring("basic".Length).Trim();

            if (string.IsNullOrEmpty(token))
            {
                return AuthenticateResult.Fail("Unauthorized");
            }

            try
            {
                return validateToken(token);
            }
            catch (Exception ex)
            {
                return AuthenticateResult.Fail(ex.Message);
            }
        }

        private AuthenticateResult validateToken(string token)
        {
            _logger.LogInformation($"{ _logPrefix }, calling validateToken method...");

            if (token != _authSettings.BasicAuthentication)
                return AuthenticateResult.Fail("Unauthorized");
            
            tokens.Add(token, _authSettings.TokenName);

            var validatedToken = Tokens.FirstOrDefault(t => t.Key == token);

            if (validatedToken.Key == null)
            {
                _logger.LogInformation($"{ _logPrefix }, user unauthorized");
                return AuthenticateResult.Fail("Unauthorized");
            }
            var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, validatedToken.Value),
                };

            var identity = new ClaimsIdentity(claims, Scheme.Name);
            var principal = new System.Security.Principal.GenericPrincipal(identity, null);
            var ticket = new AuthenticationTicket(principal, Scheme.Name);
            return AuthenticateResult.Success(ticket);
        }
    }
}
