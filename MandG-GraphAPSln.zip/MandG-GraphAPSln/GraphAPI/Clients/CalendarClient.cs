﻿using GraphAPI.Configuration;
using GraphAPI.Models.Calendar;
using GraphAPI.Services;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace GraphAPI.Clients
{
    #region ICalendarClient
    public interface ICalendarClient
    {
        Task<CalendarResponse> GetCalendarAllLists();
        Task<CalendarResponse> CreateEvent(CreateEventRequestModel createEventParams);
        Task<CalendarResponse> CreateEventMultiLocations(CreateEventMultiLocRequestModel createEventMultiLocParams);
        Task<CalendarResponse> CreateEventRecurrent(CreateEventRecurrentRequestModel createEventRecurrentParams);
    }
    #endregion
    public class CalendarClient : ICalendarClient
    {
        #region Variables

        private readonly IOAuthService _oAuthService;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly GraphAPISettings _appSettings;
        private HttpClient httpClient;
        private const string ServiceName = "Calendar-Service";
        #endregion

        #region Constructor-CalendarClient
        public CalendarClient(IOAuthService oAuthService, IHttpClientFactory httpClientFactory, IOptions<GraphAPISettings> appSettings)
        {
            _oAuthService = oAuthService;
            _httpClientFactory = httpClientFactory;
            _appSettings = appSettings.Value;
        }
        #endregion

        #region GetCalendarAllLists
        public async Task<CalendarResponse> GetCalendarAllLists()
        {
            httpClient = _httpClientFactory.CreateClient(ServiceName);
            httpClient.BaseAddress = new Uri(_appSettings.BaseUrl);
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var token = await _oAuthService.GetToken();
            httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {token.Token}");
            var request = new HttpRequestMessage(HttpMethod.Get, $"{_appSettings.BaseUrl}/v1.0/users?$select=displayname,id");
            var result = await httpClient.SendAsync(request);

            if (result.IsSuccessStatusCode)
            {
                var rawContent = await result.Content.ReadAsStringAsync();
                var values = JsonConvert.DeserializeObject<CalendarResponse>(rawContent);
                return values;
            }

            throw new Exception($"Failed to get TranscriptStatus {result.StatusCode}, {await result.Content.ReadAsStringAsync()}");
        }
        #endregion

        #region CreateEvent
        public async Task<CalendarResponse> CreateEvent(CreateEventRequestModel createEventParams)
        {
            httpClient = _httpClientFactory.CreateClient(ServiceName);
            httpClient.BaseAddress = new Uri(_appSettings.BaseUrl);
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var token = await _oAuthService.GetToken();
            httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {token.Token}");

            var _convertJsonEventRequest = JsonConvert.SerializeObject(createEventParams);
            var _formEventBody = new StringContent(_convertJsonEventRequest, Encoding.UTF8, "application/json");

            var request = new HttpRequestMessage()
            {
                Method = HttpMethod.Post,
                RequestUri = new Uri($"{_appSettings.BaseUrl}/{"userPrincipalName"}/events"),
                Content = _formEventBody
            };

            var response = await httpClient.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var eventCreatedResponse = JsonConvert.DeserializeObject<CalendarResponse>(await response.Content.ReadAsStringAsync());

                return new CalendarResponse()
                {
                    
                };
            }
            throw new Exception($"Create event request failed status code : {(int)response.StatusCode}");
        }
        #endregion

        #region CreateEventMultiLocations
        public async Task<CalendarResponse> CreateEventMultiLocations(CreateEventMultiLocRequestModel createEventParams)
        {
            httpClient = _httpClientFactory.CreateClient(ServiceName);
            httpClient.BaseAddress = new Uri(_appSettings.BaseUrl);
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var token = await _oAuthService.GetToken();
            httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {token.Token}");

            var _convertJsonEventRequest = JsonConvert.SerializeObject(createEventParams);
            var _formEventBody = new StringContent(_convertJsonEventRequest, Encoding.UTF8, "application/json");

            var request = new HttpRequestMessage()
            {
                Method = HttpMethod.Post,
                RequestUri = new Uri($"{_appSettings.BaseUrl}/{"userPrincipalName"}/events"),
                Content = _formEventBody
            };

            var response = await httpClient.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var eventCreatedResponse = JsonConvert.DeserializeObject<CalendarResponse>(await response.Content.ReadAsStringAsync());

                return new CalendarResponse()
                {

                };
            }
            throw new Exception($"Create event request failed status code : {(int)response.StatusCode}");
        }
        #endregion

        #region CreateEventRecurrent
        public async Task<CalendarResponse> CreateEventRecurrent(CreateEventRecurrentRequestModel createEventParams)
        {
            httpClient = _httpClientFactory.CreateClient(ServiceName);
            httpClient.BaseAddress = new Uri(_appSettings.BaseUrl);
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var token = await _oAuthService.GetToken();
            httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {token.Token}");

            var _convertJsonEventRequest = JsonConvert.SerializeObject(createEventParams);
            var _formEventBody = new StringContent(_convertJsonEventRequest, Encoding.UTF8, "application/json");

            var request = new HttpRequestMessage()
            {
                Method = HttpMethod.Post,
                RequestUri = new Uri($"{_appSettings.BaseUrl}/{"userPrincipalName"}/events"),
                Content = _formEventBody
            };

            var response = await httpClient.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var eventCreatedResponse = JsonConvert.DeserializeObject<CalendarResponse>(await response.Content.ReadAsStringAsync());

                return new CalendarResponse()
                {

                };
            }
            throw new Exception($"Create event request failed status code : {(int)response.StatusCode}");
        }
        #endregion
    }
}
