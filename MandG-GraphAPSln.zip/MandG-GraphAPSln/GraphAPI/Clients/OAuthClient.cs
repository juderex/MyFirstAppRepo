﻿using GraphAPI.Configuration;
using GraphAPI.Models.OAuth;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace GraphAPI.Clients
{
    #region IOAuthClient
    public interface IOAuthClient
    {
        Task<OAuthToken> GetToken();
    }
    #endregion

    #region OAuthClient
    public class OAuthClient : IOAuthClient
    {
        #region Dependencies

        private readonly IHttpClientFactory _httpClientFactory;
        private readonly OAuthTokenSettings _oauthSettings;
        private HttpClient httpClient;
        private const string ServiceName = "OAuth-Service";
        #endregion

        #region Constructor-OAuthClient
        public OAuthClient(IHttpClientFactory httpClientFactory, IOptions<OAuthTokenSettings> oauthSettings)
        {
            _httpClientFactory = httpClientFactory;
            _oauthSettings = oauthSettings.Value;
        }
        #endregion

        #region GetToken
        public async Task<OAuthToken> GetToken()
        {
            httpClient = _httpClientFactory.CreateClient(ServiceName);
            httpClient.BaseAddress = new Uri(_oauthSettings.BaseUrl);
            Dictionary<string, string> postParams = new Dictionary<string, string>();
            postParams.Add("grant_type", "client_credentials");
            postParams.Add("client_id", _oauthSettings.ClientId);
            postParams.Add("client_secret", _oauthSettings.ClientSecret);
            postParams.Add("scope", _oauthSettings.Scope);

            var request = new HttpRequestMessage()
            {
                Method = HttpMethod.Post,
                RequestUri = new Uri($"{_oauthSettings.BaseUrl}/{_oauthSettings.TenantId}/oauth2/v2.0/token"),
                Content = new FormUrlEncodedContent(postParams)
            };

            var response = await httpClient.SendAsync(request);
            if (response.IsSuccessStatusCode)
            {
                var oAuthTokenResponse = JsonConvert.DeserializeObject<OAuthTokenResponse>(await response.Content.ReadAsStringAsync());

                return new OAuthToken()
                {
                    Token = oAuthTokenResponse.AccessToken,
                    ExpiresIn = oAuthTokenResponse.ExpiresIn,
                    ExtExpiresIn = oAuthTokenResponse.ExtExpiresIn,
                    TokenType = oAuthTokenResponse.TokenType,
                    ExpiresAt = DateTime.UtcNow.AddMinutes(5)
                };
            }
            throw new Exception($"OAuth Token login request failed status code : {(int)response.StatusCode}");
        }
        #endregion
    }
    #endregion
}
