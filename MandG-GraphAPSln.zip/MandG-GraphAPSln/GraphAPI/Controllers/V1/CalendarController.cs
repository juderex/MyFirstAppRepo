﻿using GraphAPI.Models.Calendar;
using GraphAPI.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;
using System.Net;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace GraphAPI.Controllers.V1
{
    [Authorize]
    [ApiController]
    [Route("v1/[controller]")]
    [ApiVersion("1.0")]
    public class CalendarController : ControllerBase
    {
        private ICalendarService _calendarService;
        private readonly ILogger<CalendarController> _logger; // Adding the ILogger service  
        private static string _logPrefix = "MandG Graph API - ";
        public CalendarController(ICalendarService calendarService, ILogger<CalendarController> logger)
        {
            _calendarService = calendarService;
            _logger = logger;
        }

        // GET: api/<CalendarController>
        [HttpGet]
        [SwaggerOperation(Summary = "Get Calendar Details", Description = "", OperationId = "", Tags = new[] { "" })]
        [SwaggerResponse((int) HttpStatusCode.OK)]
        [Produces("application/json")]
        public async Task<ActionResult<CalendarResponse>>  Get()
        {
            _logger.LogInformation($"{ _logPrefix }, calling get method...");

            var calanderLists = await _calendarService.GetCalendarsList();
            return Ok(calanderLists);
        }

        // POST api/<CalendarController>
        [HttpPost("CreateEvent")]
        public async Task<ActionResult<CalendarResponse>> CreateEvent([FromBody] CreateEventRequestModel eventParams)
        {
            _logger.LogInformation($"{ _logPrefix }, calling create event method...");

            var _eventCreated = await _calendarService.CreateEvent(eventParams);
            return Created("Created an event in the specified time zone", _eventCreated);
        }

        // POST api/<CalendarController>
        [HttpPost("CreateEventInMultipleLocations")]
        public async Task<ActionResult<CalendarResponse>> CreateEventInMultipleLocations([FromBody] CreateEventMultiLocRequestModel eventMultiLocParams)
        {
            _logger.LogInformation($"{ _logPrefix }, calling create event in multiple locations method...");

            var _eventCreated = await _calendarService.CreateEventMultiLocations(eventMultiLocParams);
            return Created("Created an event that occurs in multiple locations", _eventCreated);
        }

        // POST api/<CalendarController>
        [HttpPost("CreateRecurringEvent")]
        public async Task<ActionResult<CalendarResponse>> CreateRecurringEvent([FromBody] CreateEventRecurrentRequestModel eventRecurrentParams)
        {
            _logger.LogInformation($"{ _logPrefix }, calling create recurring event method...");

            var _eventCreated = await _calendarService.CreateEventRecurrent(eventRecurrentParams);
            return Created("Event Created Succesfull", _eventCreated);
        }
    }
}
