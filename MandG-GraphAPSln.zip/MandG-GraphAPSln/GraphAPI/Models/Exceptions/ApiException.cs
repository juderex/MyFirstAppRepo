﻿namespace GraphAPI.Models.Exceptions
{
    public class ApiException
    {
       
    }
}
