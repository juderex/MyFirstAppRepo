﻿using System;
using System.Collections.Generic;

namespace GraphAPI.Models.Calendar
{
    public class CreateEventRequestModel
    {
        public string Subject { get; set; }
        public Body Body { get; set; }
        public Start Start { get; set; }
        public End End { get; set; }
        public Location Location { get; set; }
        public List<Attendee> Attendees { get; set; }
        public bool AllowNewTimeProposals { get; set; }
        public string TransactionId { get; set; }
    }

    public class Body
    {
        public string ContentType { get; set; }
        public string Content { get; set; }
    }
    public class Start
    {
        public DateTime DateTime { get; set; }
        public string TimeZone { get; set; }
    }
    public class End
    {
        public DateTime DateTime { get; set; }
        public string TimeZone { get; set; }
    }

    public class Location
    {
        public string DisplayName { get; set; }
    }
    public class Attendee
    {
        public EmailAddress EmailAddress { get; set; }
        public string Type { get; set; }
    }
    public class EmailAddress
    {
        public string Address { get; set; }
        public string Name { get; set; }
    }
}
