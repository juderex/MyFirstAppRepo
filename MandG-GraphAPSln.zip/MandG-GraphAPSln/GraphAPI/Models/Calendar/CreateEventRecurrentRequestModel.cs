﻿using System;
using System.Collections.Generic;

namespace GraphAPI.Models.Calendar
{
    public class CreateEventRecurrentRequestModel
    {
        public string Subject { get; set; }
        public Body Body { get; set; }
        public Start Start { get; set; }
        public End End { get; set; }
        public Recurrence Recurrence { get; set; }
        public Location Location { get; set; }
        public List<Attendee> Attendees { get; set; }
        public bool AllowNewTimeProposals { get; set; }
    }
    public class Recurrence
    {
        public Pattern Pattern { get; set; }
        public Range Range { get; set; }
    }
    
    public class Pattern
    {
        public string Type { get; set; }
        public int Interval { get; set; }
        public string[] DaysOfWeek { get; set; }
    }
    public class Range
    {
        public string Type { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
