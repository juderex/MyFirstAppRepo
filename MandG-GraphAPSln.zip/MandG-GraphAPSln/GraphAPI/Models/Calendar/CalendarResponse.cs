﻿namespace GraphAPI.Models.Calendar
{
    public class CalendarResponse
    {
        public value[] value { get; set; }
    }

    public class value
    {
        public string displayName { get; set; }
        public string id { get; set; }
    }
}
