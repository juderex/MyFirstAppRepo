﻿using System.Collections.Generic;

namespace GraphAPI.Models.Calendar
{
    public class CreateEventMultiLocRequestModel
    {
        public string Subject { get; set; }
        public Body Body { get; set; }
        public Start Start { get; set; }
        public End End { get; set; }
        public Location Location { get; set; }
        public List<Locations> Locations { get; set; }
        public List<Attendee> Attendees { get; set; }
        public bool AllowNewTimeProposals { get; set; }
    }

    public class Locations
    {
        public string DisplayName { get; set; }
        public Address Address { get; set; }
        public Coordinates Coordinates { get; set; }
    }

    public class Address
    {
        public string Street { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string CountryOrRegion { get; set; }
        public string PostalCode { get; set; }
    }
    public class Coordinates
    {
        public string Latitude { get; set; }
        public string Longitude { get; set; }
    }
}

