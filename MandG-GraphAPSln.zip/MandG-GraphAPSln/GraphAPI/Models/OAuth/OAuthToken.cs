﻿using System;

namespace GraphAPI.Models.OAuth
{
    public class OAuthToken
    {
        public string TokenType { get; set; }
        public int ExpiresIn { get; set; }
        public int ExtExpiresIn { get; set; }
        public string Token { get; set; }
        public DateTime ExpiresAt { get; set; }
    }
}
